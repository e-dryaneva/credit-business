import {AfterViewInit,Directive,ElementRef,NgZone,OnDestroy} from '@angular/core';

/** Compare the sticky footer with its normal-flow anchor, without moving layout. */
@Directive({selector:'[stickyFooter]',standalone:true})
export class StickyFooterDirective implements AfterViewInit,OnDestroy {
 private marker=document.createElement('span');
 private observer?:ResizeObserver;
 private frame=0;
 private readonly schedule=()=>{
  if(!this.frame)this.frame=requestAnimationFrame(()=>{this.frame=0;this.update()});
 };
 constructor(private element:ElementRef<HTMLElement>,private zone:NgZone){}
 ngAfterViewInit(){
  const footer=this.element.nativeElement;
  this.marker.setAttribute('aria-hidden','true');
  this.marker.style.cssText='position:absolute;left:0;top:0;width:0;height:0;pointer-events:none';
  // An absolute child in the same grid cell has its static position at the
  // cell's start, independently of the sticky footer's visual displacement.
  const anchor=document.createElement('div');
  anchor.style.cssText='position:relative;grid-column:1;height:0;pointer-events:none';
  anchor.append(this.marker);
  footer.before(anchor);
  this.zone.runOutsideAngular(()=>{
   window.addEventListener('scroll',this.schedule,{passive:true});
   window.addEventListener('resize',this.schedule);
   this.observer=new ResizeObserver(this.schedule);
   this.observer.observe(footer.parentElement!);
   this.observer.observe(footer);
   this.schedule();
  });
 }
 private update(){
  const footer=this.element.nativeElement;
  if(!footer.getClientRects().length)return;
  const normalTop=this.marker.getBoundingClientRect().top+parseFloat(getComputedStyle(footer).marginTop);
  footer.classList.toggle('footer--stuck',footer.getBoundingClientRect().top<normalTop-1);
 }
 ngOnDestroy(){
  cancelAnimationFrame(this.frame);this.observer?.disconnect();
  window.removeEventListener('scroll',this.schedule);window.removeEventListener('resize',this.schedule);
  this.marker.parentElement?.remove();
 }
}
