import {PledgeHelpComponent,PledgeRemovalComponent} from './pledge-dialogs.component';
import {Component,Input,Output,EventEmitter,OnInit,ViewEncapsulation,signal,computed} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {TuiAvatarComponent,TuiLinkComponent,TuiAppBarComponent,TuiHeaderComponent,TuiButtonComponent,TuiInputComponent,TuiCardLargeCellListComponent,TuiCellTextComponent} from '@tui/design-system';
import {Loan,MOCK_LOANS,calculateCredit,loanTerms,formatMonths,PledgeAssignments} from './credit-calculation';
@Component({selector:'app-loan-settings',standalone:true,imports:[PledgeHelpComponent,PledgeRemovalComponent,FormsModule,TuiAvatarComponent,TuiLinkComponent,TuiAppBarComponent,TuiHeaderComponent,TuiButtonComponent,TuiInputComponent,TuiCardLargeCellListComponent,TuiCellTextComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./pledge-allocation.css','./loan-settings.css'],template:`
<section class="loan-settings">
<tui-app-bar class="settings-back" start="link" center="none" end="none" startLinkText="Назад" [startLinkHref]="null" startLinkIconLeft="assets/figma/schedule/chevron-left.svg" (startLinkClick)="back.emit()"></tui-app-bar>
<tui-header class="settings-heading" size="large-h3" titleText="Какие условия вам нужны"></tui-header>
<div class="settings-fields">
<div class="settings-control"><tui-input size="large" label="Сумма кредита" inputMode="numeric" [showClear]="false" [showChevron]="false" [ngModel]="amountText()" (ngModelChange)="amountChanged($event)" [invalid]="!!error()" [errorHint]="error()"></tui-input><div class="settings-range"><input type="range" aria-label="Сумма кредита, ползунок" min="100000" [max]="draft().maxAmount" step="1000" [value]="draft().amount" [style.--fill]="((draft().amount-100000)/(draft().maxAmount-100000)*100)+'%'" (input)="slideAmount($event)"><div><span>от 100 000 ₽</span><span>до {{money(draft().maxAmount)}}</span></div></div></div>
<div class="settings-control"><tui-input size="large" label="Срок кредита" [readOnly]="true" [showClear]="false" [showChevron]="false" [ngModel]="duration(draft().months)"></tui-input><div class="settings-range"><input type="range" aria-label="Срок кредита, месяцев" [min]="minMonths()" [max]="maxMonths()" step="3" [value]="draft().months" [style.--fill]="((draft().months-minMonths())/(maxMonths()-minMonths())*100)+'%'" (input)="slideMonths($event)"><div><span>{{minMonths()===36?'от 3 лет':'от 3 месяцев'}}</span><span>{{maxMonths()===12?'до 12 месяцев':'до 5 лет'}}</span></div></div></div>
</div>
<tui-card-large-cell-list class="settings-summary" mode="flat"><tui-cell-text cell size="small" caption="" subtitle="" title="Ежемесячный платеж" [showRightColumn]="true" [rightTitle]="money(totals().monthly)" rightCaption="" rightSubtitle=""></tui-cell-text><tui-cell-text cell size="small" caption="" subtitle="" title="Ставка" [showRightColumn]="true" [rightTitle]="rate()+'%'" rightCaption="" rightSubtitle=""></tui-cell-text></tui-card-large-cell-list>
@for(id of visiblePledges();track id){
<tui-card-large-cell-list class="allocation-asset settings-pledge" mode="flat">
 <div header class="settings-pledge-heading"><tui-header size="large-h6" titleText="Авто в залог"></tui-header><tui-link variant="action" size="large" text="Удалить" (linkClick)="removingPledge.set(id)"></tui-link></div>
 <div cell class="allocation-asset-row"><tui-avatar class="allocation-car" size="small" type="icon" icon="assets/figma/allocation/car-reference.svg"></tui-avatar><div class="allocation-asset-text"><p>{{id===0?'Mercedes-Benz W214':'+ '+money(pledgeExtra(id))}}</p><small>{{id===0?'KMM97678':id===4?'KMM97678 · Mercedes-Benz W214':'Lada Granta'}}</small></div><tui-button class="allocation-help-inline" variant="secondary" size="small" (click)="help.set(true)">Как это работает</tui-button></div>
 <tui-button actions class="allocation-help-mobile" variant="secondary" size="medium" (click)="help.set(true)">Как это работает</tui-button>
</tui-card-large-cell-list>}
@if(help()){<app-pledge-help (closed)="help.set(false)"></app-pledge-help>}
@if(removingPledge()!==null){<app-pledge-removal (closed)="removingPledge.set(null)" (confirmed)="confirmRemovePledge()"></app-pledge-removal>}
<div class="settings-save"><tui-button size="large" variant="primary" [disabled]="!!error()" (click)="save()">Сохранить</tui-button></div>
</section>
`})
export class LoanSettingsComponent implements OnInit{
 @Input({required:true}) loan!:Loan;@Input() selected:readonly number[]=[];@Input() assignments:PledgeAssignments={};
 @Output() pledgesSaved=new EventEmitter<number[]>();
 @Output() back=new EventEmitter<void>();@Output() saved=new EventEmitter<Loan>();
 help=signal(false);draftSelected=signal<readonly number[]>([]);
 attachedPledges=computed(()=>[4,5].filter(id=>this.draftSelected().includes(id)&&this.assignments[id]===this.draft().id));
 removingPledge=signal<number|null>(null);
 visiblePledges=computed(()=>[...(this.draft().requiresCar?[0]:[]),...this.attachedPledges()]);
 confirmRemovePledge(){
  const id=this.removingPledge();if(id===null)return;
  if(id===0)this.draft.update(loan=>({...loan,requiresCar:false}));
  else this.draftSelected.update(v=>v.filter(item=>item!==id));
  this.removingPledge.set(null);
 }
 pledgeExtra(id:number){return Math.floor(this.draft().amount*this.draft().benefits[id].extraPercent/100/1000)*1000}
 save(){this.pledgesSaved.emit(this.attachedPledges());this.saved.emit(this.draft())}
 draft=signal<Loan>(MOCK_LOANS[0]);amountText=signal('');error=signal('');
 totals=computed(()=>calculateCredit([this.draft()],[this.draft().id,...this.draftSelected().filter(x=>x===4||x===5)],this.assignments));
 rate=computed(()=>new Intl.NumberFormat('ru-RU').format(loanTerms(this.draft(),this.draftSelected(),this.assignments).rate));
 minMonths=computed(()=>this.draft().minMonths??3);
 maxMonths=computed(()=>this.draft().maxMonths??60);
 ngOnInit(){this.draftSelected.set([...this.selected]);this.draft.set({...this.loan});this.amountText.set(this.money(this.loan.amount))}
 money(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)+' ₽'}
 duration(n:number){if(n%12)return formatMonths(n);const y=n/12;return y+' '+(y===1?'год':y<5?'года':'лет')}
 amountChanged(v:string){this.amountText.set(v);const n=Number(v.replace(/[\s₽]/g,''));if(!Number.isFinite(n)||n<100000||n>this.draft().maxAmount||n%1000){this.error.set('От 100 000 до '+this.money(this.draft().maxAmount)+', шаг 1 000 ₽');return}this.error.set('');this.draft.update(l=>({...l,amount:n}))}
 slideAmount(e:Event){const amount=Number((e.target as HTMLInputElement).value);this.draft.update(l=>({...l,amount}));this.amountText.set(this.money(amount));this.error.set('')}
 slideMonths(e:Event){this.draft.update(l=>({...l,months:Math.max(this.minMonths(),Math.min(this.maxMonths(),Number((e.target as HTMLInputElement).value)))}))}
}
