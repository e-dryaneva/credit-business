import {Directive,ElementRef,EventEmitter,OnDestroy,Output} from '@angular/core';

export const SHEET_EXIT = {duration:240,easing:'cubic-bezier(.4,0,1,1)'} as const;

/** Keep the dialog mounted (and focus trapped) until its shared exit finishes. */
@Directive({selector:'[creditSheetClose]',standalone:true,exportAs:'creditSheetClose'})
export class SheetCloseDirective implements OnDestroy {
 @Output() afterSheetClose=new EventEmitter<string>();
 private animation?:Animation;
 private closing=false;
 private destroyed=false;
 constructor(private readonly host:ElementRef<HTMLElement>){}
 close(action='close'){
  if(this.closing)return;
  this.closing=true;
  const root=this.host.nativeElement;
  const panel=root.querySelector<HTMLElement>('.tui-dialog')??root;
  root.classList.add('credit-sheet-closing');
  this.animation=panel.animate([{transform:'translateY(0)'},{transform:'translateY(100dvh)'}],{
   ...SHEET_EXIT,duration:matchMedia('(prefers-reduced-motion: reduce)').matches?0:SHEET_EXIT.duration,fill:'forwards',
  });
  this.animation.finished.then(()=>{
   if(this.destroyed)return;
   this.afterSheetClose.emit(action);
   this.animation?.cancel();root.classList.remove('credit-sheet-closing');this.closing=false;
  }).catch(()=>{});
 }
 ngOnDestroy(){this.destroyed=true;this.animation?.cancel()}
}
