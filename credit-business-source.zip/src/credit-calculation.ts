/** Fictional offers for this prototype. Fees are one-time, included in instalments. */
export interface Loan { id:number; title:string; amount:number; maxAmount:number; months:number; requiresCar?:boolean; fee:number; benefits:Record<number,{extraPercent:number;discount:number}> }
export const MOCK_LOANS: Loan[] = [
 {id:1,title:'Оборотный кредит',amount:600000,maxAmount:1200000,months:6,fee:3,benefits:{4:{extraPercent:20,discount:.5},5:{extraPercent:30,discount:1}}},
 {id:2,requiresCar:true,title:'Кредит на оборудование',amount:1500000,maxAmount:3000000,months:12,fee:5,benefits:{4:{extraPercent:15,discount:1},5:{extraPercent:25,discount:1.5}}},
 {id:3,title:'Кредит на развитие',amount:2400000,maxAmount:5000000,months:24,fee:8,benefits:{4:{extraPercent:10,discount:.5},5:{extraPercent:20,discount:2}}},
 {id:6,title:'Кредит на закупку товара',amount:900000,maxAmount:1800000,months:9,fee:4,benefits:{4:{extraPercent:15,discount:.5},5:{extraPercent:25,discount:1}}},
 {id:7,requiresCar:true,title:'Кредит на ремонт',amount:1800000,maxAmount:3500000,months:18,fee:6,benefits:{4:{extraPercent:10,discount:.5},5:{extraPercent:30,discount:1.5}}},
 {id:8,title:'Кредит на исполнение контракта',amount:350000,maxAmount:700000,months:3,fee:2.5,benefits:{4:{extraPercent:20,discount:.5},5:{extraPercent:20,discount:.5}}},
];
export type PledgeAssignments = Readonly<Partial<Record<number,number>>>;
export function loanTerms(loan:Loan, selected:readonly number[], assignments?:PledgeAssignments) {
 const benefits=[4,5].filter(id=>selected.includes(id)&&(!assignments||assignments[id]===loan.id)).map(id=>loan.benefits[id]);
 const extra=benefits.reduce((sum,b)=>sum+Math.floor(loan.amount*b.extraPercent/100/1000)*1000,0);
 const rate=Math.max(0,loan.fee-benefits.reduce((sum,b)=>sum+b.discount,0));
 const total=loan.amount+extra;
 return {extra,rate,total,commission:Math.round(total*rate)/100};
}
export function calculateCredit(loans:readonly Loan[],selected:readonly number[],assignments?:PledgeAssignments) {
 const active=loans.filter(l=>selected.includes(l.id));
 const months=Math.max(0,...active.map(l=>l.months));
 const scheduleKopecks=Array<number>(months).fill(0);
 let immediate=0,deferred=0,commissionKopecks=0,weightedRate=0;
 for(const loan of active){
  const terms=loanTerms(loan,selected,assignments);
  immediate+=loan.amount;deferred+=terms.extra;weightedRate+=loan.amount*terms.rate;
  const fee=Math.round(terms.total*terms.rate);commissionKopecks+=fee;
  const repayment=terms.total*100+fee;const regular=Math.floor(repayment/loan.months);
  for(let i=0;i<loan.months;i++)scheduleKopecks[i]+=i===loan.months-1?repayment-regular*(loan.months-1):regular;
 }
 const schedule=scheduleKopecks.map(n=>n/100);
 return {total:immediate+deferred,immediate,deferred,commission:commissionKopecks/100,
  commissionPercent:immediate?weightedRate/immediate:0,monthly:schedule[0]??0,schedule,months,
  loanCount:active.length,pledgeCount:active.length?[4,5].filter(id=>selected.includes(id)).length:0};
}
/** Exact assigned benefit, or the minimum benefit among eligible selected loans. */
export function pledgeBenefit(loans:readonly Loan[],selected:readonly number[],id:number,assignments:PledgeAssignments={}){
 const active=loans.filter(loan=>selected.includes(loan.id));
 const target=selected.includes(id)?active.find(loan=>loan.id===assignments[id]):undefined;
 const without=selected.filter(x=>x!==id);
 const options=(target?[target]:active).map(loan=>{
  const before=loanTerms(loan,without,assignments);
  const after=loanTerms(loan,[...without,id],{...assignments,[id]:loan.id});
  return {extra:after.total-before.total,discount:before.rate-after.rate};
 });
 return {extra:options.length?Math.min(...options.map(v=>v.extra)):0,
  discount:options.length?Math.min(...options.map(v=>v.discount)):0,exact:!!target};
}

export function formatMonths(months:number):string {
 const last=months%10, lastTwo=months%100;
 const word=lastTwo>=11&&lastTwo<=14?'месяцев':last===1?'месяц':last>=2&&last<=4?'месяца':'месяцев';
 return `${months} ${word}`;
}
