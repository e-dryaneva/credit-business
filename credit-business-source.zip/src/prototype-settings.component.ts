import {Component,Input,Output,EventEmitter,signal} from '@angular/core';
import {TuiButtonComponent,TuiDialogComponent,TuiRadioButtonComponent} from '@tui/design-system';

export const SCENARIOS = [
 {id:'multiple-pledges',title:'Несколько кредитов и залоги'},
 {id:'two-unsecured',title:'Два кредита без залогов'},
 {id:'single-required',title:'Один кредит с обязательным залогом'},
 {id:'single-unsecured',title:'Один кредит без залога'},
] as const;
export type Scenario = typeof SCENARIOS[number]['id'];
export function loadScenario():Scenario {
 let value:string|null=null;
 try {value=new URL(location.href).searchParams.get('scenario')??localStorage.getItem('credit-form-scenario')}catch{}
 return SCENARIOS.find(item=>item.id===value)?.id??'multiple-pledges';
}
/** Same draft/apply and URL + storage persistence pattern as payment-settings in ПФ. */
@Component({selector:'app-prototype-settings',standalone:true,imports:[TuiButtonComponent,TuiDialogComponent,TuiRadioButtonComponent],styles:[`
 :host{display:contents}.prototype-trigger{position:fixed;right:24px;bottom:24px;z-index:40}
 .prototype-options{display:grid;gap:20px;padding:8px 0}
 @media(max-width:767px){.prototype-trigger{right:12px;bottom:calc(174px + env(safe-area-inset-bottom))}}
`],template:`
 <tui-button class="prototype-trigger" variant="primary-grayscale" size="medium" [rounded]="true" iconLeft="assets/prototype/settings.svg" ariaLabel="Настройки кредитной формы" (click)="show()"></tui-button>
 <tui-dialog [open]="open()" title="Настройки формы" [showSubtitle]="false" primaryActionLabel="Применить" secondaryActionLabel="Отмена" actionSize="large" [fullWidthActions]="true" (primaryClick)="apply()" (secondaryClick)="open.set(false)" (openChange)="!$event && open.set(false)">
  <div class="prototype-options" role="radiogroup" aria-label="Наполнение кредитной формы">
   @for(item of scenarios;track item.id){<tui-radiobutton name="credit-scenario" variant="accent" [title]="item.title" [checked]="draft()===item.id" (change)="draft.set(item.id)"></tui-radiobutton>}
  </div>
 </tui-dialog>`})
export class PrototypeSettingsComponent {
 @Input() scenario:Scenario='multiple-pledges';
 @Output() applied=new EventEmitter<Scenario>();
 readonly scenarios=SCENARIOS;open=signal(false);draft=signal<Scenario>('multiple-pledges');
 show(){this.draft.set(this.scenario);this.open.set(true)}
 apply(){const value=this.draft();try{localStorage.setItem('credit-form-scenario',value)}catch{}
  const url=new URL(location.href);url.searchParams.set('scenario',value);history.replaceState(history.state,'',url);
  this.applied.emit(value);this.open.set(false);
 }
}
