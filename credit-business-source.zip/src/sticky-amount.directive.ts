import {AfterViewInit,Directive,ElementRef,Input,NgZone,OnDestroy} from '@angular/core';

/** Keep the original amount typography stable; scroll frames only move and scale its layer. */
@Directive({selector:'[stickyAmount]',standalone:true})
export class StickyAmountDirective implements AfterViewInit,OnDestroy {
 @Input({required:true}) stickyAmountTarget!:HTMLElement;
 private frame=0;
 private destroyed=false;
 private dirty=true;
 private displayedProgress:number|undefined;
 private lastTime=0;
 private resize?:ResizeObserver;
 private textObserver?:MutationObserver;
 private geometry?:{title:HTMLElement;nav:HTMLElement;distance:number;x:number;y:number;largeScale:number};
 private readonly reduced=matchMedia('(prefers-reduced-motion: reduce)');
 private readonly schedule=()=>{
  if(!this.frame&&!this.destroyed)this.frame=requestAnimationFrame(time=>{this.frame=0;this.update(time)});
 };
 private readonly invalidate=()=>{this.dirty=true;this.schedule()};
 constructor(private readonly element:ElementRef<HTMLElement>,private readonly zone:NgZone){}
 ngAfterViewInit(){
  this.zone.runOutsideAngular(()=>{
   window.addEventListener('scroll',this.schedule,{passive:true});
   window.addEventListener('resize',this.invalidate);
   this.reduced.addEventListener('change',this.schedule);
   this.resize=new ResizeObserver(this.invalidate);
   this.resize.observe(this.element.nativeElement);
   this.resize.observe(this.stickyAmountTarget);
   // Amount changes require new metrics, but decorative digit reels do not.
   const heading=this.element.nativeElement.querySelector('h1');
   if(heading){this.textObserver=new MutationObserver(this.invalidate);this.textObserver.observe(heading,{childList:true,characterData:true,subtree:true})}
   document.fonts.ready.then(this.invalidate);
   this.schedule();
  });
 }
 private measure(){
  const root=this.element.nativeElement,target=this.stickyAmountTarget;
  const heading=root.querySelector<HTMLElement>('h1');
  const title=target.querySelector<HTMLElement>('.summary-title');
  if(!heading||!title||!root.getClientRects().length)return false;
  const nav=target.parentElement!;
  const close=nav.querySelector('button')!.getBoundingClientRect();
  const source=heading.getBoundingClientRect();
  const destination=target.getBoundingClientRect();
  const heroStyle=getComputedStyle(heading);
  const largeSize=parseFloat(heroStyle.fontSize);
  const smallSize=parseFloat(getComputedStyle(target).fontSize);
  const endY=close.top+close.height/2;
  this.geometry={title,nav,distance:Math.max(1,source.top+source.height/2+window.scrollY-endY),
   x:source.left+source.width/2-destination.left,y:endY-destination.top,largeScale:largeSize/smallSize};
  // These layout-affecting writes happen only on resize or amount changes.
  title.style.left='0';title.style.top='0';
  title.style.fontFamily=heroStyle.fontFamily;
  title.style.fontSize=`${largeSize}px`;
  title.style.fontWeight=heroStyle.fontWeight;
  title.style.lineHeight=heroStyle.lineHeight;
  title.style.letterSpacing=heroStyle.letterSpacing;
  nav.style.setProperty('--summary-height',`${nav.offsetHeight}px`);
  nav.classList.add('credit-topbar--amount-ready');
  this.dirty=false;
  return true;
 }
 private update(time:number){
  if(this.dirty&&!this.measure())return;
  const g=this.geometry;if(!g)return;
  const progress=Math.min(1,Math.max(0,window.scrollY/g.distance));
  // A new wheel gesture starts with a normal frame, not the entire idle time.
  const dt=this.lastTime?Math.min(32,time-this.lastTime):16;
  const previous=this.displayedProgress;
  let displayed=previous===undefined||this.reduced.matches?progress:
   previous+(progress-previous)*(1-Math.exp(-dt/75));
  if(Math.abs(progress-displayed)<0.0001)displayed=progress;
  this.displayedProgress=displayed;
  const eased=displayed*displayed*(3-2*displayed);
  const scale=1+(1/g.largeScale-1)*eased;
  if(previous!==undefined&&displayed!==previous){
   g.title.querySelector('.summary-value')?.dispatchEvent(new Event('amount-morph'));
  }
  g.title.style.transform=`translate3d(${g.x}px,${g.y+g.distance*(1-displayed)}px,0) translate(-50%,-50%) scale(${scale})`;
  g.nav.classList.toggle('credit-topbar--pinned',displayed===1);
  g.nav.classList.toggle('credit-topbar--scrolled',window.scrollY>0);
  this.lastTime=displayed!==progress?time:0;
  if(displayed!==progress)this.schedule();
 }
 ngOnDestroy(){
  this.destroyed=true;cancelAnimationFrame(this.frame);
  this.resize?.disconnect();this.textObserver?.disconnect();
  window.removeEventListener('scroll',this.schedule);
  window.removeEventListener('resize',this.invalidate);
  this.reduced.removeEventListener('change',this.schedule);
 }
}
