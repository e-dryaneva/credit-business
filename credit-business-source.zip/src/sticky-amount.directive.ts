import {AfterViewInit,Directive,ElementRef,Input,NgZone,OnDestroy} from '@angular/core';

/** One visible amount follows a stable layout placeholder into the app bar.
 * Scroll changes only its transform; reversing scroll reverses the same path.
 */
@Directive({selector:'[stickyAmount]',standalone:true})
export class StickyAmountDirective implements AfterViewInit,OnDestroy {
 @Input({required:true}) stickyAmountTarget!:HTMLElement;
 private frame=0;
 private destroyed=false;
 private displayedProgress:number|undefined;
 private lastTime=0;
 private resize?:ResizeObserver;
 private readonly reduced=matchMedia('(prefers-reduced-motion: reduce)');
 private readonly schedule=()=>{
  if(!this.frame&&!this.destroyed)this.frame=requestAnimationFrame(time=>{this.frame=0;this.update(time)});
 };
 constructor(private readonly element:ElementRef<HTMLElement>,private readonly zone:NgZone){}
 ngAfterViewInit(){
  this.zone.runOutsideAngular(()=>{
   window.addEventListener('scroll',this.schedule,{passive:true});
   window.addEventListener('resize',this.schedule);
   this.reduced.addEventListener('change',this.schedule);
   this.resize=new ResizeObserver(this.schedule);
   this.resize.observe(this.element.nativeElement);
   this.resize.observe(this.stickyAmountTarget);
   document.fonts.ready.then(this.schedule);
   this.schedule();
  });
 }
 private update(time:number){
  const root=this.element.nativeElement,target=this.stickyAmountTarget;
  const heading=root.querySelector<HTMLElement>('h1');
  const title=target.querySelector<HTMLElement>('.summary-title');
  if(!heading||!title||!root.getClientRects().length)return;
  const nav=target.parentElement!;
  const bar=nav.getBoundingClientRect();
  const close=nav.querySelector('button')!.getBoundingClientRect();
  const source=heading.getBoundingClientRect();
  const destination=target.getBoundingClientRect();
  const heroStyle=getComputedStyle(heading);
  // This probe always keeps the design system app-bar typography. The moving
  // child has its own font, so reading it cannot feed back into these metrics.
  const compactStyle=getComputedStyle(target);
  const largeSize=parseFloat(heroStyle.fontSize);
  const smallSize=parseFloat(compactStyle.fontSize);
  const endY=close.top+close.height/2;
  const sourceY=source.top+source.height/2;
  const distance=Math.max(1,sourceY+window.scrollY-endY);
  const progress=Math.min(1,Math.max(0,window.scrollY/distance));
  // Filter wheel steps with a frame-rate-independent, non-overshooting follow.
  // Clamp the target first so scrolling far down never delays the return.
  const dt=this.lastTime?Math.min(64,time-this.lastTime):16;
  this.lastTime=time;
  const previous=this.displayedProgress;
  let displayed=previous===undefined||this.reduced.matches?progress:
   previous+(progress-previous)*(1-Math.exp(-dt/75));
  if(Math.abs(progress-displayed)<0.0001)displayed=progress;
  this.displayedProgress=displayed;
  const eased=displayed*displayed*(3-2*displayed);
  const pinned=displayed===1;
  if(previous!==undefined&&displayed!==previous){
   title.querySelector('.summary-value')?.dispatchEvent(new Event('amount-morph'));
  }
  const scale=1+(smallSize/largeSize-1)*eased;
  const centerX=source.left+source.width/2;
  const y=endY+distance*(1-displayed);
  title.style.top=`${y-destination.top}px`;
  title.style.left=`${centerX-destination.left}px`;

  title.style.fontSize=`${largeSize}px`;
  title.style.lineHeight=heroStyle.lineHeight;
  title.style.fontFamily=pinned?compactStyle.fontFamily:heroStyle.fontFamily;
  title.style.fontWeight=String(Math.round(Number(heroStyle.fontWeight)+(Number(compactStyle.fontWeight)-Number(heroStyle.fontWeight))*eased));
  title.style.letterSpacing=pinned?`${(parseFloat(compactStyle.letterSpacing)||0)/scale}px`:heroStyle.letterSpacing;
  // Match the two fonts' widths continuously as well as their sizes. Switching
  // to the app-bar font at the endpoint must not shift individual text bounds.
  const range=document.createRange();
  range.selectNodeContents(heading);
  const largeWidth=range.getBoundingClientRect().width;
  const smallWidth=target.querySelector<HTMLElement>('.summary-metric')!.getBoundingClientRect().width;
  const width=largeWidth+(smallWidth-largeWidth)*eased;
  const scaleX=width/(title.offsetWidth||1);
  title.style.transform=`translate(-50%,-50%) scale(${scaleX},${scale})`;
  nav.classList.add('credit-topbar--amount-ready');
  nav.classList.toggle('credit-topbar--pinned',pinned);
  nav.classList.toggle('credit-topbar--scrolled',window.scrollY>0);
  nav.style.setProperty('--summary-height',`${nav.offsetHeight}px`);
  if(displayed!==progress)this.schedule();
 }
 ngOnDestroy(){
  this.destroyed=true;
  cancelAnimationFrame(this.frame);
  this.resize?.disconnect();
  window.removeEventListener('scroll',this.schedule);
  window.removeEventListener('resize',this.schedule);
  this.reduced.removeEventListener('change',this.schedule);
 }
}
