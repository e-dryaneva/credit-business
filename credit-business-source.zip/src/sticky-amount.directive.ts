import {AfterViewInit,Directive,ElementRef,Input,NgZone,OnDestroy} from '@angular/core';

/** Native sticky owns vertical positioning, including compositor-driven scrolling.
 * Only size and the local progress-bar offset interpolate; no per-frame scroll
 * compensation can lag behind the browser and shake the pinned amount.
 */
@Directive({selector:'[stickyAmount]',standalone:true})
export class StickyAmountDirective implements AfterViewInit,OnDestroy {
 @Input({required:true}) stickyAmountTarget!:HTMLElement;
 private frame=0;
 private destroyed=false;
 private resize?:ResizeObserver;
 private readonly reduced=matchMedia('(prefers-reduced-motion: reduce)');
 private readonly schedule=()=>{
  if(!this.frame&&!this.destroyed)this.frame=requestAnimationFrame(()=>{this.frame=0;this.update()});
 };
 constructor(private readonly element:ElementRef<HTMLElement>,private readonly zone:NgZone){}
 ngAfterViewInit(){
  this.zone.runOutsideAngular(()=>{
   window.addEventListener('scroll',this.schedule,{passive:true});
   window.addEventListener('resize',this.schedule);
   this.reduced.addEventListener('change',this.schedule);
   this.resize=new ResizeObserver(this.schedule);
   this.resize.observe(this.element.nativeElement);
   this.resize.observe(this.stickyAmountTarget);
   document.fonts.ready.then(this.schedule);
   this.schedule();
  });
 }
 private update(){
  const root=this.element.nativeElement,target=this.stickyAmountTarget;
  const heading=root.querySelector<HTMLElement>('h1');
  const progress=root.querySelector<HTMLElement>('tui-progress-bar');
  if(!heading||!progress||!root.getClientRects().length)return;
  const anchor=root.previousElementSibling!;
  const rootBounds=root.getBoundingClientRect();
  const destination=target.getBoundingClientRect();
  const headingTop=heading.parentElement!.offsetTop+heading.offsetTop;
  const headingLeft=rootBounds.left+heading.parentElement!.offsetLeft+heading.offsetLeft;
  const progressTop=progress.parentElement!.offsetTop+progress.offsetTop;
  const progressLeft=rootBounds.left+progress.parentElement!.offsetLeft+progress.offsetLeft;
  const headingWidth=heading.offsetWidth,progressWidth=progress.offsetWidth;
  if(!headingWidth||!progressWidth)return;
  const fontSize=parseFloat(getComputedStyle(heading).fontSize);
  const targetStyle=getComputedStyle(target);
  const compactSize=parseFloat(targetStyle.getPropertyValue('--summary-font-size'));
  const compactScale=compactSize/fontSize;
  // Align the compact amount with the actual DS button, not an unrelated top
  // offset. Its line height differs between desktop and mobile typefaces.
  const closeButton=target.parentElement!.querySelector('button')!.getBoundingClientRect();
  const compactHeadingTop=closeButton.top+(closeButton.height-heading.offsetHeight*compactScale)/2;
  const stickyTop=compactHeadingTop-headingTop;
  root.style.setProperty('--amount-sticky-top',`${stickyTop}px`);
  const travel=Math.max(1,anchor.getBoundingClientRect().top+window.scrollY-stickyTop);
  const distance=Math.min(1,Math.max(0,window.scrollY/travel));
  const fraction=this.reduced.matches?(distance>=1?1:0):distance*distance*(3-2*distance);
  const mix=(from:number,to:number)=>from+(to-from)*fraction;
  const scale=mix(1,compactScale);
  const compactCenter=destination.left+destination.width/2;
  const center=mix(headingLeft+headingWidth/2,compactCenter);
  const x=center-headingWidth*scale/2-headingLeft;
  heading.style.transform=`translate3d(${x}px,0,0) scale(${scale})`;
  const fullWidthBar=targetStyle.getPropertyValue('--summary-progress-full-width').trim()==='1';
  const compactBarLeft=fullWidthBar?rootBounds.left:destination.left;
  const compactBarWidth=fullWidthBar?rootBounds.width:destination.width;
  const barX=mix(progressLeft,compactBarLeft)-progressLeft;
  const compactBarTop=headingTop+heading.offsetHeight*compactScale+12;
  const barY=mix(progressTop,compactBarTop)-progressTop;
  progress.style.transform=`translate3d(${barX}px,${barY}px,0) scale(${mix(1,compactBarWidth/progressWidth)},${mix(1,4/progress.offsetHeight)})`;
  root.style.setProperty('--summary-progress',String(fraction));
  const nav=target.parentElement!;
  nav.style.setProperty('--summary-progress',String(fraction));
  nav.style.setProperty('--summary-height',`${compactHeadingTop-nav.getBoundingClientRect().top+heading.offsetHeight*compactScale+28}px`);
 }
 ngOnDestroy(){
  this.destroyed=true;
  cancelAnimationFrame(this.frame);
  this.resize?.disconnect();
  window.removeEventListener('scroll',this.schedule);
  window.removeEventListener('resize',this.schedule);
  this.reduced.removeEventListener('change',this.schedule);
 }
}
