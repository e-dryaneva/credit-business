import {Component,Input,Output,EventEmitter,ViewEncapsulation,signal,OnDestroy} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {TuiDialogComponent,TuiInputComponent,TuiLinkComponent,TuiButtonComponent,TuiHeaderComponent} from '@tui/design-system';

@Component({selector:'app-disbursement',standalone:true,imports:[FormsModule,TuiDialogComponent,TuiInputComponent,TuiLinkComponent,TuiButtonComponent,TuiHeaderComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./disbursement.css'],template:`
@if(!confirmed()){
 <tui-dialog class="credit-confirmation" [open]="true" title="Подтверждение" [showSubtitle]="false" primaryActionLabel="" secondaryActionLabel="" (openChange)="closed.emit()">
  <div class="confirmation-content">
   <p>Отправили код на номер +7 916 ***-**-04</p>
   <tui-input size="large" label="Код" type="password" inputMode="numeric" autocomplete="one-time-code" [showClear]="false" [showChevron]="false" [ngModel]="code()" (ngModelChange)="enterCode($event)" [invalid]="invalid()" errorHint="Неверный код. Попробуйте ещё раз"></tui-input>
   <div class="confirmation-links">
    <tui-link size="small" [href]="null" [text]="resent()?'Код отправлен':'Отправить снова'" [disabled]="resent()" (linkClick)="resend()"></tui-link>
    <tui-link size="small" [href]="null" text="Не приходит код" (linkClick)="help.set(!help())"></tui-link>
    <tui-link size="small" [href]="null" text="Отмена" (linkClick)="closed.emit()"></tui-link>
   </div>
   @if(help()){<p class="confirmation-help">Для проверки прототипа введите код 1234.</p>}
  </div>
 </tui-dialog>
} @else {
 <section class="disbursement-status" aria-label="Статус зачисления">
  <div class="disbursement-nav"><tui-button variant="flat" size="small" (click)="closed.emit()">Закрыть</tui-button></div>
  <div class="disbursement-body">
   <div class="disbursement-art"><div class="coins-clock" aria-hidden="true">
    @for(part of parts;track part){<picture [class]="'coin-layer '+part"><source media="(max-width:767px)" [srcset]="asset(part,true)"><img [src]="asset(part,false)" alt=""></picture>}
   </div></div>
   <div class="disbursement-copy"><tui-header size="large-h4" [titleText]="'Зачисляем '+money(immediate)+' на счет'"></tui-header>
    @if(deferred>0){<p>Осталось загрузить {{documents()}}, чтобы получить еще {{money(deferred)}}</p>}
   </div>
   <div class="disbursement-actions">
    @if(deferred>0){<tui-button variant="primary" size="large" (click)="upload.set(true)">{{car&&!apartment?'К загрузке СТС':'К загрузке документов'}}</tui-button>}
    <tui-button variant="flat" size="large" (click)="closed.emit()">На главную</tui-button>
   </div>
  </div>
 </section>
 <tui-dialog class="credit-upload" [open]="upload()" title="Загрузка документов" [showSubtitle]="false" primaryActionLabel="Готово" secondaryActionLabel="" (openChange)="upload.set(false)" (primaryClick)="upload.set(false)">
  <p>Выберите {{documents()}}.</p><input type="file" accept="image/*,.pdf" multiple aria-label="Выбрать документы" (change)="filesChanged($event)">
  @if(fileNames()){<p>{{fileNames()}}</p>}
 </tui-dialog>
}
`})
export class DisbursementComponent implements OnDestroy {
 @Input() immediate=0;@Input() deferred=0;@Input() car=false;@Input() apartment=false;
 @Output() closed=new EventEmitter<void>();@Output() accepted=new EventEmitter<void>();
 code=signal('');invalid=signal(false);help=signal(false);resent=signal(false);confirmed=signal(false);upload=signal(false);fileNames=signal('');
 private timer:ReturnType<typeof setTimeout>|undefined;
 private previousOverflow=document.body.style.overflow;
 parts=['bubble','coin','coin2','clock'];
 constructor(){document.body.style.overflow='hidden'}
 ngOnDestroy(){document.body.style.overflow=this.previousOverflow;clearTimeout(this.timer)}
 enterCode(value:string){const code=value.replace(/\D/g,'').slice(0,4);this.code.set(code);this.invalid.set(false);if(code.length===4){if(code==='1234'){this.confirmed.set(true);document.body.style.overflow=this.previousOverflow;this.accepted.emit();window.scrollTo(0,0)}else this.invalid.set(true)}}
 resend(){this.code.set('');this.invalid.set(false);this.resent.set(true);clearTimeout(this.timer);this.timer=setTimeout(()=>this.resent.set(false),30000)}
 documents(){return this.car&&this.apartment?'фото СТС и документы на квартиру':this.car?'фото СТС':'документы на квартиру'}
 money(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)+' ₽'}
 asset(part:string,mobile:boolean){return 'assets/figma/confirmation/'+(mobile?'mobile'+part[0].toUpperCase()+part.slice(1):part)+'.svg'}
 filesChanged(event:Event){this.fileNames.set(Array.from((event.target as HTMLInputElement).files||[]).map(f=>f.name).join(', '))}
}
