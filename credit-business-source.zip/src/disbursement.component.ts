import {SheetCloseDirective} from './sheet-close.directive';
import {Component,Input,Output,EventEmitter,ViewEncapsulation,signal,OnDestroy} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {TuiDialogComponent,TuiInputComponent,TuiLinkComponent,TuiButtonComponent,TuiHeaderComponent} from '@tui/design-system';

@Component({selector:'app-disbursement',standalone:true,imports:[SheetCloseDirective,FormsModule,TuiDialogComponent,TuiInputComponent,TuiLinkComponent,TuiButtonComponent,TuiHeaderComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./disbursement.css'],template:`
@if(!confirmed()){
 <tui-dialog creditSheetClose #modalClose="creditSheetClose" (afterSheetClose)="$event==='confirm'?acceptCode():closed.emit()" class="credit-confirmation" [open]="true" title="Подтверждение" [showSubtitle]="false" primaryActionLabel="" secondaryActionLabel="" (openChange)="modalClose.close()">
  <div class="confirmation-content">
   <p>Отправили код на номер +7 916 ***-**-04</p>
   <tui-input size="large" label="Код" type="password" inputMode="numeric" autocomplete="one-time-code" [showClear]="false" [showChevron]="false" [ngModel]="code()" (ngModelChange)="enterCode($event,modalClose)" [invalid]="invalid()" errorHint="Неверный код. Попробуйте ещё раз"></tui-input>
   <div class="confirmation-links">
    <tui-link size="small" [href]="null" [text]="resent()?'Код отправлен':'Отправить снова'" [disabled]="resent()" (linkClick)="resend()"></tui-link>
    <tui-link size="small" [href]="null" text="Не приходит код" (linkClick)="help.set(!help())"></tui-link>
    <tui-link size="small" [href]="null" text="Отмена" (linkClick)="modalClose.close()"></tui-link>
   </div>
   @if(help()){<p class="confirmation-help">Для проверки прототипа введите любые 4 цифры.</p>}
  </div>
 </tui-dialog>
} @else {
 <section creditSheetClose #statusClose="creditSheetClose" (afterSheetClose)="closed.emit()" class="disbursement-status" aria-label="Статус зачисления">
  <div class="disbursement-nav"><tui-button variant="flat" size="small" (click)="statusClose.close()">Закрыть</tui-button></div>
  <div class="disbursement-body">
   <div class="disbursement-art"><div class="coins-clock" aria-hidden="true">
    @for(part of parts;track part){<picture [class]="'coin-layer '+part"><source media="(max-width:767px)" [srcset]="asset(part,true)"><img [src]="asset(part,false)" alt=""></picture>}
   </div></div>
   <div class="disbursement-copy"><tui-header size="large-h4" [titleText]="'Зачисляем '+money(immediate+deferred)+' на счет'"></tui-header>
    <p>Когда закончим, пришлем СМС</p>
   </div>
   <div class="disbursement-actions">
    <tui-button variant="primary" size="large" (click)="statusClose.close()">Понятно</tui-button>
   </div>
  </div>
 </section>
}
`})
export class DisbursementComponent implements OnDestroy {
 @Input() immediate=0;@Input() deferred=0;@Input() car=false;
 @Output() closed=new EventEmitter<void>();@Output() accepted=new EventEmitter<void>();
 code=signal('');invalid=signal(false);help=signal(false);resent=signal(false);confirmed=signal(false);
 private timer:ReturnType<typeof setTimeout>|undefined;
 private previousOverflow=document.body.style.overflow;
 parts=['bubble','coin','coin2','clock'];
 constructor(){document.body.style.overflow='hidden'}
 ngOnDestroy(){document.body.style.overflow=this.previousOverflow;clearTimeout(this.timer)}
 enterCode(value:string,close:SheetCloseDirective){const code=value.replace(/\D/g,'').slice(0,4);this.code.set(code);this.invalid.set(false);if(code.length===4)close.close('confirm')}
 acceptCode(){this.confirmed.set(true);document.body.style.overflow=this.previousOverflow;this.accepted.emit();window.scrollTo(0,0)}
 resend(){this.code.set('');this.invalid.set(false);this.resent.set(true);clearTimeout(this.timer);this.timer=setTimeout(()=>this.resent.set(false),30000)}
 money(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)+' ₽'}
 asset(part:string,mobile:boolean){return 'assets/figma/credit-flow/'+(mobile?'mobile'+part[0].toUpperCase()+part.slice(1):part)+'.svg'}
}
