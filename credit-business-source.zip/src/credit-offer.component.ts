import {Component,Input,Output,EventEmitter,ViewEncapsulation} from '@angular/core';
import {TuiCardLargeCellListComponent,TuiButtonComponent,TuiCheckboxComponent,TuiRadioButtonComponent,TuiBadgeComponent} from '@tui/design-system';
import {Loan,formatMonths} from './credit-calculation';

@Component({selector:'app-credit-card',standalone:true,imports:[TuiCardLargeCellListComponent,TuiButtonComponent,TuiCheckboxComponent,TuiRadioButtonComponent,TuiBadgeComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./credit-offer.css'],template:`
<tui-card-large-cell-list class="loan-card" mode="elevated">
 <div cell class="loan-card-content" (click)="selectRadio()">
  <div class="loan-card-row">
   <strong class="loan-card-amount">@if(previousAmount!==undefined&&previousAmount!==amount){<span class="loan-card-before"><del>{{money(previousAmount)}}</del> → </span>}{{money(amount)}}</strong>
   <div class="loan-card-actions">
    @if(editable&&checked){<tui-button class="configure-credit" variant="secondary" size="x-small" [rounded]="true" iconLeft="assets/figma/mobile-imgColor.svg" title="Настроить кредит" [ariaLabel]="'Настроить кредит '+loan.id" (click)="edit.emit()"></tui-button>}
    @if(selection==='radio'){<tui-radiobutton variant="primary" [title]="''" [attr.aria-label]="loan.title" [checked]="checked" (change)="changed.emit()"></tui-radiobutton>}
    @else{<tui-checkbox variant="primary" [checked]="checked" [disabled]="disabled" [title]="''" [attr.aria-label]="'Выбрать кредит '+loan.id" (change)="changed.emit()"></tui-checkbox>}
   </div>
  </div>
  <p class="loan-card-description">{{loan.title}}</p>
  <div class="loan-card-chips">
   @if(previousRate!==undefined&&previousRate!==rate){<span class="loan-card-fee-comparison"><tui-badge size="large" variant="light-text" class="loan-card-percent" content="icon" icon="assets/figma/compact/compact-percent.svg"></tui-badge><del>{{number(previousRate)}}%</del><span>→ {{number(rate)}}%</span></span>}
   <tui-badge [class.loan-card-new-fee]="previousRate!==undefined&&previousRate!==rate" size="large" variant="light-text" class="loan-card-percent" content="icon-text" icon="assets/figma/compact/compact-percent.svg" [text]="number(rate)+'%'"></tui-badge>
   <tui-badge size="large" variant="light-text" class="loan-card-calendar" content="icon-text" icon="assets/figma/compact/compact-calendar.svg" [text]="formatMonths(loan.months)"></tui-badge>
   @if(monthly!==undefined){<tui-badge class="loan-card-monthly" size="large" variant="light-text" content="icon-text" icon="assets/figma/allocation/calendar-arrow.svg" [text]="money(monthly)+' в месяц'"></tui-badge>}
   @if(car){<tui-badge size="large" variant="light-text" class="loan-card-car" content="icon-text" icon="assets/figma/offer-chips/car.svg" text="Залог авто"></tui-badge>}
   @if(apartment){<tui-badge size="large" variant="light-text" content="text" text="Залог квартиры"></tui-badge>}
  </div>
 </div>
</tui-card-large-cell-list>`})
export class CreditOfferComponent {
 @Input({required:true}) loan!:Loan;
 @Input({required:true}) amount=0;
 @Input({required:true}) rate=0;
 @Input() checked=false;
 @Input() disabled=false;
 @Input() editable=true;
 @Input() selection:'checkbox'|'radio'='checkbox';
 @Input() previousAmount?:number;
 @Input() previousRate?:number;
 @Input() monthly?:number;
 @Input() car=false;
 @Input() apartment=false;
 @Output() changed=new EventEmitter<void>();
 @Output() edit=new EventEmitter<void>();
 selectRadio():void {if(this.selection==='radio')this.changed.emit()}
 formatMonths=formatMonths;
 number(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)}
 money(n:number){return this.number(n)+' ₽'}
}
