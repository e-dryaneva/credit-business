import {CreditOfferComponent} from './credit-offer.component';
import {StickyAmountDirective} from './sticky-amount.directive';
import {PledgeAllocationComponent} from './pledge-allocation.component';
import {LoanSettingsComponent} from './loan-settings.component';
import {DisbursementComponent} from './disbursement.component';
import {PaymentScheduleComponent} from './payment-schedule.component';
import {CREDIT_MOTION} from './credit-motion';
import {RollingNumberDirective} from './rolling-number.directive';
import {Component,signal,computed} from '@angular/core';
import {NgTemplateOutlet} from '@angular/common';
import {calculateCredit,MOCK_LOANS,loanTerms,pledgeBenefit,Loan,formatMonths,PledgeAssignments} from './credit-calculation';
import {bootstrapApplication} from '@angular/platform-browser';
import {TuiLinkComponent,TuiButtonComponent,TuiCardLargeCellListComponent,TuiHeaderComponent,TuiCellTextComponent,TuiBadgeComponent,TuiDialogComponent,TuiCheckboxComponent,TuiProgressBarComponent} from '@tui/design-system';
@Component({selector:'app-root',standalone:true,imports:[CreditOfferComponent,NgTemplateOutlet,TuiLinkComponent,StickyAmountDirective,PledgeAllocationComponent,LoanSettingsComponent,DisbursementComponent,PaymentScheduleComponent,RollingNumberDirective,TuiButtonComponent,TuiCardLargeCellListComponent,TuiHeaderComponent,TuiCellTextComponent,TuiBadgeComponent,TuiDialogComponent,TuiCheckboxComponent,TuiProgressBarComponent],template:`
@if(disbursementOpen()){<app-disbursement [immediate]="totals().immediate" [deferred]="totals().deferred" [car]="selected().includes(4)" [apartment]="selected().includes(5)" (accepted)="disbursementAccepted.set(true)" (closed)="disbursementOpen.set(false);disbursementAccepted.set(false)"></app-disbursement>}
@if(pendingPledges().length){<app-pledge-allocation [loans]="activeLoans()" [selected]="selected()" [assignments]="assignments()" [pledgeId]="pendingPledges()[0]" (back)="cancelAllocation()" (confirmed)="confirmAllocation($event)"></app-pledge-allocation>}
@if(settingsOpen()){<app-loan-settings [loan]="editingLoan()" [selected]="selected()" [assignments]="assignments()" (back)="closeSettings()" (saved)="saveSettings($event)"></app-loan-settings>}
@if(scheduleOpen()){<app-payment-schedule [payments]="totals().schedule" [total]="totals().total" [loans]="loans()" [selected]="selected()" [assignments]="assignments()" (back)="closeSchedule()"></app-payment-schedule>}
<main class="compact-screen" [hidden]="scheduleOpen()||disbursementAccepted()||settingsOpen()||pendingPledges().length" [attr.inert]="disbursementOpen()?'':null" [style.--credit-motion-duration]="motion.duration+'ms'" [style.--credit-motion-easing]="motion.easing"><nav class="credit-topbar"><div #summaryTarget class="summary-target" aria-hidden="true"></div><tui-button variant="flat" size="small" (click)="dialog.set('Закрыть подбор кредита?')">Закрыть</tui-button></nav>
<div class="amount-anchor" aria-hidden="true"></div><section class="amount" stickyAmount [stickyAmountTarget]="summaryTarget"><p>Сколько хотите взять?</p><div class="amount-heading-slot"><h1 aria-live="polite" [rollingValue]="totals().total" [rollingText]="money(totals().total)">{{money(totals().total)}}</h1></div><div class="amount-progress-slot"><tui-progress-bar size="large" [progress]="progress()" ariaLabel="Доля выбранной суммы в доступных предложениях"></tui-progress-bar></div></section><p class="amount-limit">Выбрано {{money(totals().total)}} из {{money(available())}}</p>
<div class="layout"><div class="products"><section><div class="section-heading"><tui-header size="large-h4" titleText="Кредиты"></tui-header><tui-link class="all-link" variant="action" [size]="mobile?'x-large':'large'" [attr.aria-expanded]="allExpanded()" aria-controls="additional-loans" [text]="allExpanded()?'Свернуть':'Все'" (linkClick)="allExpanded.set(!allExpanded())"></tui-link></div><ng-template #loanCard let-item><app-credit-card [loan]="item" [amount]="terms(item).total" [rate]="rate(item)" [checked]="selected().includes(item.id)" [disabled]="selected().includes(item.id)&&totals().loanCount===1" [car]="item.requiresCar||(hasImprovement(item)&&assignments()[4]===item.id)" [apartment]="hasImprovement(item)&&assignments()[5]===item.id" (changed)="toggle(item.id)" (edit)="openSettings(item.id)"></app-credit-card></ng-template>
<div class="cards">@for(item of primaryLoans();track item.id){<ng-container [ngTemplateOutlet]="loanCard" [ngTemplateOutletContext]="{$implicit:item}"></ng-container>}</div>
<div id="additional-loans" class="extra-loans" [class.extra-loans--open]="allExpanded()" [attr.inert]="allExpanded()?null:''" [attr.aria-hidden]="!allExpanded()">@for(item of additionalLoans();track item.id;let step=$index){<div class="loan-reveal-step" [style.--step]="step"><div class="loan-reveal-clip"><div class="loan-reveal-content"><ng-container [ngTemplateOutlet]="loanCard" [ngTemplateOutletContext]="{$implicit:item}"></ng-container></div></div></div>}</div></section>
<section class="improvements"><div class="section-heading improvement-heading"><tui-header size="large-h4" titleText="Улучшить условия"></tui-header><img class="compact-flash" src="assets/figma/compact/compact-flash.svg" alt=""></div><div class="cards">@for(item of pledges;track item.id){<tui-card-large-cell-list mode="elevated"><div cell class="offer"><div class="details"><div class="row"><strong>{{mobile?item.mobile:item.title}}</strong><tui-checkbox variant="primary" [checked]="selected().includes(item.id)" [disabled]="!totals().loanCount" [attr.aria-label]="item.title" (change)="toggle(item.id)"></tui-checkbox></div><p>{{item.description}}</p>@if(totals().loanCount){<div class="chips"><tui-badge size="large" variant="light-text" class="cash" content="icon-text" icon="assets/figma/compact/compact-cash.svg" [text]="(benefit(item.id).exact?'+':'от +')+money(benefit(item.id).extra)"></tui-badge><tui-badge size="large" variant="light-text" class="percent" content="icon-text" icon="assets/figma/compact/compact-percent.svg" [text]="(benefit(item.id).exact?'−':'от −')+number(benefit(item.id).discount)+'%'"></tui-badge></div>}</div></div></tui-card-large-cell-list>}</div></section></div>
<tui-card-large-cell-list class="conditions" mode="flat"><tui-cell-text cell subtitle="" size="medium" caption="Счет зачисления" title="Рублевый счет"></tui-cell-text><tui-cell-text cell subtitle="" size="medium" caption="Первый платёж в месяц" [title]="money(totals().monthly)"></tui-cell-text><tui-cell-text cell subtitle="" size="medium" caption="Зачислим сразу" [title]="money(totals().immediate)"></tui-cell-text><tui-cell-text cell subtitle="" size="medium" caption="Зачислим после загрузки документов" [title]="money(totals().deferred)"></tui-cell-text><tui-button actions [disabled]="!totals().loanCount" variant="secondary" size="medium" (click)="openSchedule()">График платежей</tui-button></tui-card-large-cell-list>
<footer><tui-button [disabled]="!totals().loanCount" variant="primary" size="large" (click)="disbursementOpen.set(true)">Получить деньги</tui-button><p class="legal legal-desktop">Нажимая «Получить деньги», вы соглашаетесь <button (click)="dialog.set('Условия предложения')">с условиями</button>.<br>Они доступны до 15 декабря 2026 года</p><p class="legal legal-mobile">Нажимая <button (click)="dialog.set('Условия предложения')">«Получить деньги»</button>, вы соглашаетесь<br>с условиями. Они доступны до 15 декабря 2026 года</p></footer></div></main>
<tui-dialog [open]="!!dialog()" [title]="dialog()" (openChange)="dialog.set('')" primaryActionLabel="Готово" (primaryClick)="dialog.set('')">
@if(dialog()==='Настроить кредит'){<label>Сумма кредита<input type="number" min="100000" [max]="editingLoan().maxAmount" step="1000" [value]="editingLoan().amount" (input)="setAmount($event)"></label>@if(amountError()){<p role="alert">{{amountError()}}</p>}<p>Разовая комиссия {{number(rate(editingLoan()))}}%. Срок — {{formatMonths(editingLoan().months)}}. Доступно до {{money(editingLoan().maxAmount)}}.</p>}
@else if(dialog()==='Выбранные предложения'){<p>Выбрано кредитов: {{totals().loanCount}}. Залогов: {{totals().pledgeCount}}. Общая сумма: {{money(totals().total)}}.</p>}
@else if(dialog()==='Закрыть подбор кредита?'){<p>Можно закрыть вкладку или вернуться к выбору кнопкой «Готово».</p>}
@else{<p>Сумма: {{money(totals().total)}}. Разовая комиссия: {{money(totals().commission)}}. Срок: до {{formatMonths(totals().months)}}. Всего к возврату: {{money(totals().total+totals().commission)}}.</p>}
</tui-dialog>`})
class App{
readonly motion=CREDIT_MOTION;
settingsOpen=signal(false);private settingsScroll=0;
openSettings(id:number){this.settingsScroll=window.scrollY;this.editing.set(id);this.settingsOpen.set(true);window.scrollTo(0,0)}
closeSettings(){this.settingsOpen.set(false);requestAnimationFrame(()=>window.scrollTo(0,this.settingsScroll))}
saveSettings(loan:Loan){this.loans.update(items=>items.map(item=>item.id===loan.id?loan:item));this.closeSettings()}
disbursementOpen=signal(false);disbursementAccepted=signal(false);
scheduleOpen=signal(false); private selectionScroll=0;
openSchedule(){this.selectionScroll=window.scrollY;this.scheduleOpen.set(true);window.scrollTo(0,0)}
closeSchedule(){this.scheduleOpen.set(false);requestAnimationFrame(()=>window.scrollTo(0,this.selectionScroll))}
mobile=matchMedia('(max-width:767px)').matches; media=matchMedia('(max-width:767px)'); selected=signal<number[]>([1]);dialog=signal('');editing=signal(1);
loans=signal<Loan[]>(MOCK_LOANS.map(loan=>({...loan})));
allExpanded=signal(false);
primaryLoans=computed(()=>this.loans().slice(0,2));
additionalLoans=computed(()=>this.loans().slice(2));
editingLoan=computed(()=>this.loans().find(loan=>loan.id===this.editing())!);
amountError=signal('');
assignments=signal<PledgeAssignments>({});
activeLoans=computed(()=>this.loans().filter(l=>this.selected().includes(l.id)));
pendingPledges=signal<number[]>([]);private allocationScroll=0;
totals=computed(()=>calculateCredit(this.loans(),this.selected(),this.assignments()));
hasImprovement(loan:Loan){return this.selected().includes(loan.id)&&[4,5].some(id=>this.selected().includes(id)&&this.assignments()[id]===loan.id)}
terms(loan:Loan){return loanTerms(loan,this.selected(),this.assignments())}
availableLoans=computed(()=>this.loans().reduce((sum,item)=>sum+item.amount,0));
available=computed(()=>{
 const loans=this.loans().map(l=>({...l,amount:l.maxAmount}));
 const assignments=Object.fromEntries([4,5].map(id=>[id,loans.reduce((best,loan)=>loan.amount*loan.benefits[id].extraPercent>best.amount*best.benefits[id].extraPercent?loan:best).id]));
 return calculateCredit(loans,[...loans.map(l=>l.id),4,5],assignments).total;
});
progress=computed(()=>this.totals().total/this.available()*100);
pledges=[{id:4,title:'Авто под залог',mobile:'Под залог авто',description:'Mercedes-Benz'},{id:5,title:'Квартира под залог',mobile:'Под залог квартиру',description:'ул. Пушкина, 56'}];
constructor(){this.media.addEventListener('change',e=>this.mobile=e.matches)}
toggle(id:number){
 const current=this.selected();
 if(id===4||id===5){
  if(current.includes(id)){this.selected.set(current.filter(x=>x!==id));this.assignments.update(v=>{const next={...v};delete next[id];return next});return}
  this.openAllocation([id]);
  return;
 }
 if(current.includes(id)&&this.activeLoans().length===1)return;
 const adding=!current.includes(id);
 this.selected.set(adding?[...current,id]:current.filter(x=>x!==id));
 const attached=[4,5].filter(p=>this.selected().includes(p)&&this.assignments()[p]===id);
 if(!adding&&attached.length){
  this.assignments.update(v=>{const next={...v};for(const p of attached)delete next[p];return next});
  this.selected.update(v=>v.filter(x=>!attached.includes(x)));
  if(this.activeLoans().length===1){const target=this.activeLoans()[0].id;this.assignments.update(v=>({...v,...Object.fromEntries(attached.map(p=>[p,target]))}));this.selected.update(v=>[...v,...attached])}
  else this.openAllocation(attached);
 }
}
openAllocation(ids:number[]){this.allocationScroll=window.scrollY;this.pendingPledges.set(ids);window.scrollTo(0,0)}
cancelAllocation(){this.pendingPledges.set([]);requestAnimationFrame(()=>window.scrollTo(0,this.allocationScroll))}
confirmAllocation(loanId:number){
 if(!this.activeLoans().some(l=>l.id===loanId))return;
 const pledgeId=this.pendingPledges()[0];if(!pledgeId)return;
 this.assignments.update(v=>({...v,[pledgeId]:loanId}));
 this.selected.update(v=>v.includes(pledgeId)?v:[...v,pledgeId]);
 this.pendingPledges.update(v=>v.slice(1));
 if(!this.pendingPledges().length)requestAnimationFrame(()=>window.scrollTo(0,this.allocationScroll));
}
rate(loan:Loan){return loanTerms(loan,this.selected(),this.assignments()).rate}
benefit(id:number){return pledgeBenefit(this.loans(),this.selected(),id,this.assignments())}
formatMonths=formatMonths;
number(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)}
paymentDate(i:number){return new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(Date.UTC(2026,11+i,25)))}
setAmount(e:Event){
 const n=Number((e.target as HTMLInputElement).value);
 if(!Number.isFinite(n)||n<100000||n>this.loans()[this.editing()-1].maxAmount||n%1000!==0){this.amountError.set('Введите сумму от 100 000 до '+this.money(this.loans()[this.editing()-1].maxAmount)+' с шагом 1 000 ₽');return}
 this.amountError.set('');this.loans.update(items=>items.map(x=>x.id===this.editing()?{...x,amount:n}:x));
}
money(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)+' ₽'}
}
bootstrapApplication(App).catch(console.error);
