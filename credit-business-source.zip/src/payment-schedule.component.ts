import {Component,Input,Output,EventEmitter,ViewEncapsulation,signal} from '@angular/core';
import {TuiAppBarComponent,TuiButtonComponent,TuiHeaderComponent,TuiCardLargeCellListComponent,TuiCellTextComponent,TuiCellDisclosureComponent} from '@tui/design-system';
import {calculateCredit,Loan,PledgeAssignments} from './credit-calculation';

@Component({selector:'app-payment-schedule',standalone:true,
 imports:[TuiAppBarComponent,TuiButtonComponent,TuiHeaderComponent,TuiCardLargeCellListComponent,TuiCellTextComponent,TuiCellDisclosureComponent],
 encapsulation:ViewEncapsulation.None,styleUrls:['./payment-schedule.css'],
 template:`
 <section class="payment-page" aria-label="График платежей">
  <tui-app-bar class="payment-back" start="link" center="none" end="none" startLinkText="Назад" [startLinkHref]="null" startLinkIconLeft="assets/figma/schedule/chevron-left.svg" (startLinkClick)="back.emit()"></tui-app-bar>
  <div class="payment-content">
   <tui-header class="payment-desktop-title" size="large-h3" titleText="График платежей"></tui-header>
   <tui-header class="payment-mobile-title" size="large-h3" titleText="Условия"></tui-header>
   <tui-card-large-cell-list class="payment-summary" mode="flat">
    <tui-cell-text cell class="payment-total" size="medium" caption="Общая сумма" [title]="money(total)" subtitle=""></tui-cell-text>
    <tui-cell-text cell size="medium" caption="Ежемесячный платеж" [title]="money(payments[0]||0)" subtitle=""></tui-cell-text>
    <tui-cell-text cell size="medium" caption="Куда поступят деньги" title="Рублевый счет · 4081" subtitle=""></tui-cell-text>
   </tui-card-large-cell-list>
   <tui-card-large-cell-list class="payment-list" mode="flat">
    <tui-header header size="large-h6" titleText="График платежей"></tui-header>
    <div cell class="payment-rows">
     @for(payment of payments;track $index;let i=$index){
      @if(i>0 && year(i)!==year(i-1)){<tui-header class="payment-year" size="large-h5" [titleText]="year(i)+''"></tui-header>}
      <tui-cell-disclosure size="large" [showAvatar]="true" avatarType="text" [avatarText]="(i+1)+''" caption="" subtitle="" [title]="date(i)" [disclosureLabel]="money(payment)" (disclosureClick)="expanded.set(expanded()===i?-1:i)"></tui-cell-disclosure>
      @if(expanded()===i){<div class="payment-breakdown">@for(loan of loans;track loan.id){@if(selected.includes(loan.id)&&i<loan.months){<tui-cell-text size="medium" [caption]="loan.title" [title]="money(loanPayment(loan,i))" subtitle=""></tui-cell-text>}}</div>}
     }
    </div>
   </tui-card-large-cell-list>
  </div>
  <div class="payment-footer"><tui-button variant="primary" size="large" (click)="back.emit()">Понятно</tui-button></div>
 </section>`})
export class PaymentScheduleComponent {
 @Input() payments:readonly number[]=[];
 @Input() total=0;
 @Input() loans:readonly Loan[]=[];
 @Input() selected:readonly number[]=[];
 @Input() assignments:PledgeAssignments={};
 @Output() back=new EventEmitter<void>();
 expanded=signal(-1);
 money(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)+' ₽'}
 date(i:number){return new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',timeZone:'UTC'}).format(new Date(Date.UTC(2026,11+i,25)))}
 year(i:number){return new Date(Date.UTC(2026,11+i,25)).getUTCFullYear()}
 loanPayment(loan:Loan,i:number){return calculateCredit([loan],this.selected,this.assignments).schedule[i]||0}
}
