/** Shared motion envelope for the amount reels and the available-credit bar. */
export const CREDIT_MOTION = {
  baseDuration: 1050,
  digitStagger: 40,
  maxStaggerIndex: 6,
  duration: 1290,
  easing: 'cubic-bezier(.22,.65,.25,1)',
} as const;
