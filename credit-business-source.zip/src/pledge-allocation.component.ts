import {CreditOfferComponent} from './credit-offer.component';
import {Component,Input,Output,EventEmitter,OnChanges,ViewEncapsulation,signal} from '@angular/core';
import {TuiAppBarComponent,TuiHeaderComponent,TuiButtonComponent,TuiCardLargeCellListComponent,TuiAvatarComponent,TuiDialogComponent} from '@tui/design-system';
import {Loan,PledgeAssignments,calculateCredit,loanTerms} from './credit-calculation';

@Component({selector:'app-pledge-allocation',standalone:true,imports:[CreditOfferComponent,TuiAppBarComponent,TuiHeaderComponent,TuiButtonComponent,TuiCardLargeCellListComponent,TuiAvatarComponent,TuiDialogComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./pledge-allocation.css'],template:`
<section class="allocation-page" aria-label="Выбор кредита для залога">
 <tui-app-bar class="allocation-back" start="link" center="none" end="none" startLinkText="Назад" [startLinkHref]="null" startLinkIconLeft="assets/figma/schedule/chevron-left.svg" (startLinkClick)="back.emit()"></tui-app-bar>
 <tui-header class="allocation-heading" size="large-h3" titleText="К какому кредиту добавите залог" descriptionText="Машина останется у вас, а деньги зачислим после проверки СТС"></tui-header>
 <div class="allocation-options" role="radiogroup" aria-label="Кредит для залога">
 @for(loan of loans;track loan.id){
  <app-credit-card [loan]="loan" [amount]="preview(loan).total" [rate]="preview(loan).rate" [checked]="choice()===loan.id" [editable]="false" selection="radio" [previousAmount]="choice()===loan.id?base(loan).total:undefined" [previousRate]="choice()===loan.id?base(loan).rate:undefined" [monthly]="monthly(loan)" (changed)="choice.set(loan.id)"></app-credit-card>
 }
 </div>
 <tui-card-large-cell-list class="allocation-asset" mode="flat">
  <tui-header header size="large-h6" titleText="Авто"></tui-header>
  <div cell class="allocation-asset-row"><tui-avatar class="allocation-car" size="small" type="icon" icon="assets/figma/allocation/car.svg" text="К"></tui-avatar><div class="allocation-asset-text"><p>{{pledgeId===4?'Mercedes-Benz':'Лада Гранта'}}</p></div><tui-button class="allocation-help-inline" variant="secondary" size="small" (click)="help.set(true)">Как это работает</tui-button></div>
  <tui-button actions class="allocation-help-mobile" variant="secondary" size="medium" (click)="help.set(true)">Как это работает</tui-button>
 </tui-card-large-cell-list>
 <div class="allocation-footer"><tui-button variant="primary" size="large" [disabled]="!choice()" (click)="confirmed.emit(choice())">Выбрать</tui-button></div>
</section>
<tui-dialog [open]="help()" title="Как это работает" [showSubtitle]="false" primaryActionLabel="Понятно" secondaryActionLabel="" (primaryClick)="help.set(false)" (openChange)="help.set(false)"><p>Залог увеличивает сумму и снижает комиссию только у выбранного кредита. Дополнительную сумму зачислим после проверки СТС.</p></tui-dialog>
`})
export class PledgeAllocationComponent implements OnChanges {
 @Input() loans:readonly Loan[]=[];
 @Input() selected:readonly number[]=[];
 @Input() assignments:PledgeAssignments={};
 @Input() pledgeId=4;
 @Output() back=new EventEmitter<void>();
 @Output() confirmed=new EventEmitter<number>();
 choice=signal(0);help=signal(false);
 ngOnChanges(){const previous=this.assignments[this.pledgeId];this.choice.set(this.loans.some(l=>l.id===previous)?previous!:this.loans[0]?.id??0)}
 private selection(){return [...this.selected.filter(id=>id!==this.pledgeId),this.pledgeId]}
 private bindings(){return {...this.assignments,[this.pledgeId]:this.choice()}}
 base(loan:Loan){return loanTerms(loan,this.selected.filter(id=>id!==this.pledgeId),this.assignments)}
 preview(loan:Loan){return loanTerms(loan,this.selection(),this.bindings())}
 monthly(loan:Loan){return calculateCredit([loan],[loan.id,...this.selection().filter(id=>id===4||id===5)],this.bindings()).monthly}
 number(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)}
 money(n:number){return this.number(n)+' ₽'}
}
