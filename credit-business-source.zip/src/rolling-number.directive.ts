import {CREDIT_MOTION} from './credit-motion';
import {AfterViewChecked, Directive, ElementRef, Input, OnDestroy} from '@angular/core';

/** Decorative digit reels over the real, accessible DS text. No changes to its layout. */
@Directive({selector: '[rollingText]', standalone: true})
export class RollingNumberDirective implements AfterViewChecked, OnDestroy {
  @Input() rollingText = '';
  @Input() rollingValue = 0;
  private previous: string | undefined;
  private previousValue = 0;
  private dispose?: () => void;
  private readonly motion = matchMedia('(prefers-reduced-motion: reduce)');
  private readonly stopMotion = () => { if (this.motion.matches) this.dispose?.(); };
  private readonly stopForMorph = () => this.dispose?.();
  constructor(private readonly element: ElementRef<HTMLElement>) {
    this.motion.addEventListener('change', this.stopMotion);
    this.element.nativeElement.addEventListener('amount-morph', this.stopForMorph);
  }
  ngAfterViewChecked() {
    if (this.previous === this.rollingText) return;
    const before = this.previous;
    const decreasing = this.rollingValue < this.previousValue;
    this.previous = this.rollingText;
    this.previousValue = this.rollingValue;
    this.dispose?.();
    if (before === undefined || this.motion.matches || !before) return;
    const host = this.element.nativeElement;
    const target = host.querySelector<HTMLElement>('.tui-cell-text__title') ?? host;
    const style = getComputedStyle(target);
    const text = target.firstChild;
    if (!text || text.nodeType !== Node.TEXT_NODE || text.textContent !== this.rollingText) return;
    const bounds = target.getBoundingClientRect();
    // Glyph rectangles include the sticky morph scale; reel coordinates are local.
    const scaleX = bounds.width / target.offsetWidth || 1;
    const lineHeight = parseFloat(style.lineHeight) || bounds.height;
    // Use the final text's glyph positions, rather than re-laying it out as flex items.
    const range = document.createRange();
    const overlay = document.createElement('span');
    overlay.className = 'rolling-number-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    Object.assign(overlay.style, {
      position: 'absolute', inset: '0', display: 'block', textAlign: 'left',
      pointerEvents: 'none', whiteSpace: 'pre', visibility: 'visible',
      font: style.font, fontVariantNumeric: style.fontVariantNumeric, letterSpacing: style.letterSpacing, color: style.color,
    });
    const oldDigits = before.replace(/\D/g, '').split('').reverse();
    const newDigits = this.rollingText.replace(/\D/g, '').length;
    let digitIndex = 0;
    const animations: Animation[] = [];
    const glyphsToFit: {element: HTMLElement; width: number}[] = [];
    for (let offset = 0; offset < this.rollingText.length; offset++) {
      const char = this.rollingText[offset];
      range.setStart(text, offset);
      range.setEnd(text, offset + 1);
      const glyph = range.getBoundingClientRect();
      const slot = document.createElement('span');
      Object.assign(slot.style, {
        position: 'absolute', top: '0', left: `${(glyph.left - bounds.left) / scaleX}px`,
        width: `${glyph.width / scaleX}px`, height: `${lineHeight}px`,
        // Keep only a subpixel allowance for antialiasing at column edges.
        // Wider intermediate digits are fitted below, not allowed to overlap.
        lineHeight: `${lineHeight}px`, overflow: 'visible',
        textAlign: 'left',
      });
      if (!/\d/.test(char)) { slot.textContent = char; overlay.append(slot); continue; }
      const from = Number(oldDigits[newDigits - 1 - digitIndex] ?? char);
      const to = Number(char);
      const index = digitIndex++;
      if (from === to) { slot.textContent = char; overlay.append(slot); continue; }
      slot.style.clipPath = 'inset(0 -0.5px)';
      const rail = document.createElement('span');
      rail.style.cssText = 'display:flex;flex-direction:column;will-change:transform;';
      const steps = ((decreasing ? from - to : to - from) + 10) % 10 + 10;
      for (let i = 0; i <= steps; i++) {
        const digit = document.createElement('span');
        digit.textContent = String(((from + (decreasing ? -i : i)) % 10 + 10) % 10);
        digit.style.cssText = `display:block;width:max-content;height:${lineHeight}px;line-height:${lineHeight}px;text-align:left;flex-shrink:0;transform-origin:left center;`;
        // The display font has proportional digits: an 8 cannot occupy the
        // advance width of a 1. Fit intermediate glyphs into that final column;
        // leave the destination glyph untouched for an exact handoff to text.
        if (digit.textContent !== char) glyphsToFit.push({element: digit, width: glyph.width / scaleX});
        if (decreasing) rail.prepend(digit);
        else rail.append(digit);
      }
      slot.append(rail); overlay.append(slot);
      animations.push(rail.animate([
        {transform: decreasing ? `translateY(-${steps * lineHeight}px)` : 'translateY(0)'},
        {transform: decreasing ? 'translateY(0)' : `translateY(-${steps * lineHeight}px)`},
      ], {duration: CREDIT_MOTION.baseDuration + Math.min(index, CREDIT_MOTION.maxStaggerIndex) * CREDIT_MOTION.digitStagger, easing: CREDIT_MOTION.easing, fill: 'forwards'}));
    }
    const position = target.style.position;
    const color = target.style.color;
    const colorPriority = target.style.getPropertyPriority('color');
    target.style.position = 'relative';
    target.style.setProperty('color', 'transparent', 'important');
    target.append(overlay);
    const renderedScale = target.getBoundingClientRect().width / target.offsetWidth || 1;
    for (const {element, width} of glyphsToFit) {
      const naturalWidth = element.getBoundingClientRect().width / renderedScale;
      if (naturalWidth > width - 1) element.style.transform = `scaleX(${Math.max(0, width - 1) / naturalWidth})`;
    }
    const timer = window.setTimeout(() => this.dispose?.(), CREDIT_MOTION.duration + 60);
    this.dispose = () => {
      clearTimeout(timer);
      animations.forEach(animation => animation.cancel());
      overlay.remove();
      target.style.position = position;
      target.style.setProperty('color', color, colorPriority);
      this.dispose = undefined;
    };
  }
  ngOnDestroy() { this.element.nativeElement.removeEventListener('amount-morph', this.stopForMorph); this.dispose?.(); this.motion.removeEventListener('change', this.stopMotion); }
}
