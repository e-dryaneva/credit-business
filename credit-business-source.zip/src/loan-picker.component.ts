import {Component,Input,Output,EventEmitter,OnInit,OnDestroy,ViewEncapsulation,signal} from '@angular/core';
import {TuiDialogComponent,TuiAppBarComponent,TuiButtonComponent,TuiCardLargeCellListComponent,TuiCheckboxComponent} from '@tui/design-system';
import {Loan} from './credit-calculation';

@Component({selector:'app-loan-picker',standalone:true,imports:[TuiDialogComponent,TuiAppBarComponent,TuiButtonComponent,TuiCardLargeCellListComponent,TuiCheckboxComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./loan-picker.css'],template:`
<tui-dialog class="loan-picker" [class.loan-picker--closing]="closing()" [open]="true" size="large" title="Какой продукт вам нужен" [closeable]="false" [dismissible]="false" [showSubtitle]="false" primaryActionLabel="" secondaryActionLabel="" (openChange)="finish(false)">
 <section class="loan-picker-page">
 <tui-app-bar class="loan-picker-back" start="link" center="none" end="none" startLinkText="Назад" [startLinkHref]="null" startLinkIconLeft="assets/figma/schedule/chevron-left.svg" (startLinkClick)="finish(false)"></tui-app-bar>
 <h2 class="loan-picker-title">Какой продукт вам нужен</h2>
 <div class="loan-picker-list">
  @for(loan of loans;track loan.id){
   <tui-card-large-cell-list mode="elevated"><div cell>
    <div class="loan-picker-heading"><h3>{{loan.title}}</h3><tui-checkbox variant="primary" [checked]="draft().includes(loan.id)" [attr.aria-label]="'Выбрать '+loan.title" (change)="toggle(loan.id)"></tui-checkbox></div>
    <p class="loan-picker-limit">До {{money(loan.maxAmount)}}</p>
    <ul class="loan-picker-terms">
     <li><span class="loan-picker-percent" aria-hidden="true"></span><span>Комиссия — {{number(loan.fee)}}%</span></li>
     <li><img src="assets/figma/loan-picker/calendar.svg" alt=""><span>Срок — до {{termLimit(loan)}}</span></li>
     <li><img src="assets/figma/loan-picker/cash.svg" alt=""><span>{{securedIds.includes(loan.id)?'Под залог авто':'Без залога'}}</span></li>
    </ul>
   </div></tui-card-large-cell-list>
  }
 </div>
 <div class="loan-picker-actions"><tui-button variant="primary" size="large" (click)="finish(true)">Добавить</tui-button></div>
 </section>
</tui-dialog>`})
export class LoanPickerComponent implements OnInit,OnDestroy {
 @Input() loans:Loan[]=[];
 @Input() selected:number[]=[];
 @Input() securedIds:number[]=[];
 @Output() confirmed=new EventEmitter<number[]>();
 @Output() closed=new EventEmitter<void>();
 draft=signal<number[]>([]);closing=signal(false);private closeTimer?:ReturnType<typeof setTimeout>;
 finish(apply:boolean){
  if(this.closing())return;
  this.closing.set(true);
  this.closeTimer=setTimeout(()=>apply?this.confirmed.emit(this.draft()):this.closed.emit(),matchMedia('(prefers-reduced-motion: reduce)').matches?0:240);
 }
 private readonly previousOverflow=document.body.style.overflow;
 ngOnInit(){this.draft.set(this.loans.filter(l=>this.selected.includes(l.id)).map(l=>l.id));document.body.style.overflow='hidden'}
 ngOnDestroy(){clearTimeout(this.closeTimer);document.body.style.overflow=this.previousOverflow}
 toggle(id:number){this.draft.update(ids=>ids.includes(id)?ids.length>1?ids.filter(x=>x!==id):ids:[...ids,id])}
 termLimit(loan:Loan){
  const months=loan.maxMonths??loan.months;
  if(months===12)return '12 месяцев';
  if(months%12===0)return `${months/12} ${months===12?'года':'лет'}`;
  return `${months} ${months%10===1&&months%100!==11?'месяца':'месяцев'}`;
 }
 number(n:number){return new Intl.NumberFormat('ru-RU',{maximumFractionDigits:2}).format(n)}
 money(n:number){return this.number(n)+' ₽'}
}
