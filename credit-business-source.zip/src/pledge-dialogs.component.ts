import {Directive,Component,EventEmitter,OnDestroy,Output,ViewEncapsulation} from '@angular/core';
import {TuiDialogComponent,TuiCardLargeCellListComponent} from '@tui/design-system';

/** Keep the underlying form and its scroll position intact while a sheet is open. */
@Directive()
class ModalScrollLock implements OnDestroy {
 private readonly overflow=document.body.style.overflow;
 constructor(){document.body.style.overflow='hidden'}
 ngOnDestroy(){document.body.style.overflow=this.overflow}
}

@Component({selector:'app-pledge-help',standalone:true,imports:[TuiDialogComponent,TuiCardLargeCellListComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./pledge-dialogs.css'],template:`
<tui-dialog class="pledge-dialog pledge-help" [open]="true" title="Авто остается у вас" subtitle="Переоформлять его на банк не нужно" [showSubtitle]="true" primaryActionLabel="Понятно" secondaryActionLabel="" actionSize="large" (openChange)="closed.emit()" (primaryClick)="closed.emit()">
 <div class="pledge-help-grid">
  <tui-card-large-cell-list class="pledge-help-documents" mode="flat"><div cell>
   <h3>Пришлите фото СТС</h3><p>Проверим его и сообщим решение — обычно это занимает 2 минуты</p>
   <div class="pledge-help-illustration"><img src="assets/figma/credit-flow/pledge-help.png" alt=""></div>
  </div></tui-card-large-cell-list>
  <tui-card-large-cell-list mode="flat"><div cell><h3>Продолжайте пользоваться машиной</h3><p>Вы остаетесь собственником и можете ездить на авто как обычно</p></div></tui-card-large-cell-list>
  <tui-card-large-cell-list mode="flat"><div cell><h3>Бесплатно оформим залог</h3><p>Вам не придется обращаться в ГИБДД или нотариальную контору</p></div></tui-card-large-cell-list>
 </div>
</tui-dialog>`})
export class PledgeHelpComponent extends ModalScrollLock {
 @Output() closed=new EventEmitter<void>();
}

@Component({selector:'app-pledge-removal',standalone:true,imports:[TuiDialogComponent],encapsulation:ViewEncapsulation.None,styleUrls:['./pledge-dialogs.css'],template:`
<tui-dialog class="pledge-dialog pledge-removal" [open]="true" title="Точно хотите удалить залог?" [showSubtitle]="false" primaryActionLabel="Да, удалить" secondaryActionLabel="Отмена" actionSize="medium" (openChange)="closed.emit()" (secondaryClick)="closed.emit()" (primaryClick)="confirmed.emit()"></tui-dialog>`})
export class PledgeRemovalComponent extends ModalScrollLock {
 @Output() closed=new EventEmitter<void>();
 @Output() confirmed=new EventEmitter<void>();
}
